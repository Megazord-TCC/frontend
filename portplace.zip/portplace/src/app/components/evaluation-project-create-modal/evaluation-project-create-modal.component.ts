import { CommonModule } from '@angular/common';
import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Project } from '../../interface/carlos-interfaces';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { environment } from '../../environments/environment';
import { firstValueFrom } from 'rxjs';

@Component({
  selector: 'app-project-evaluation-create-modal',
  imports: [CommonModule, FormsModule],
  templateUrl: './evaluation-project-create-modal.component.html',
  styleUrl: './evaluation-project-create-modal.component.scss'
})
export class ProjectEvaluationCreateModal {
  @Input() isVisible = false;

  @Output() close = new EventEmitter<void>();
  @Output() created = new EventEmitter<void>();

  httpClient = inject(HttpClient);
  route = inject(ActivatedRoute);

  strategyId = -1;
  evaluationGroupId = -1;

  inputProjectSelectedId = '';
  inputProjectsOptions: Project[] = [];

  errorMessage = '';
  isSubmitButtonDisabled = false;

  ngOnInit() {
    this.strategyId = Number(this.route.snapshot.paramMap.get('estrategiaId'));
    this.evaluationGroupId = Number(this.route.snapshot.paramMap.get('grupoAvaliacaoId'));
  }

  ngOnChanges() {
    if (this.isVisible) {
      this.restartForm();
    }
  }

  restartForm() {
    this.clearForm();
    this.setInputProjectOptions();
  }

  onOverlayClick(event: Event): void {
    if (event.target === event.currentTarget) {
      this.onClose();
    }
  }

  onClose(): void {
    this.close.emit();
  }

  async onSave(): Promise<any> {
    let isFormValid = await this.isFormValid();

    if (!isFormValid)
      return;

    let projectEvaluationsRoute = `${environment.apiUrl}/strategies/${this.strategyId}/ahps/${this.evaluationGroupId}/evaluations`;
    let body = {
      projectId: Number(this.inputProjectSelectedId),
      evaluationGroupId: this.evaluationGroupId
    }

    let postProjectEvaluation$ = this.httpClient.post(projectEvaluationsRoute, body);

    postProjectEvaluation$.subscribe({
      next: () => {
        this.created.emit();
        this.onClose();
      },
      error: () => this.errorMessage = 'Ocorreu um erro inesperado. Tente novamente mais tarde.'
    });
  }

  clearForm() {
    this.inputProjectSelectedId = '';
    this.errorMessage = '';
    this.isSubmitButtonDisabled = false;
  }

  async isFormValid(): Promise<boolean> {
    return this.isProjectSelected() && await this.isProjectNotAlreadyEvaluated();
  }

  isProjectSelected(): boolean {
    let isProjectSelected = !!this.inputProjectSelectedId.trim();

    this.errorMessage = isProjectSelected ? '' : 'Selecione um projeto para avaliar.';

    return isProjectSelected;
  }

  async isProjectNotAlreadyEvaluated(): Promise<boolean> {
    let evaluationsRoute = `${environment.apiUrl}/strategies/${this.strategyId}/ahps/${this.evaluationGroupId}/evaluations`;
    let getAllEvaluations$ = this.httpClient.get<any[]>(evaluationsRoute);
    let evaluations = await firstValueFrom(getAllEvaluations$);
    let isNotAlreadyEvaluated = !evaluations.some(evaluation => evaluation.projectId == Number(this.inputProjectSelectedId));

    this.errorMessage = isNotAlreadyEvaluated ? '' : 'Este projeto já foi cadastrado para avaliação neste grupo.';

    return isNotAlreadyEvaluated;
  }

  setInputProjectOptions() {
    // Aqui você implementará a chamada para getAllProjects()
    // Por enquanto deixo um exemplo básico que você pode ajustar
    let projectsRoute = `${environment.apiUrl}/projects`; // Ajuste conforme sua API
    let getAllProjects$ = this.httpClient.get<Project[]>(projectsRoute);

    getAllProjects$.subscribe({
      next: (projects) => {
        this.inputProjectsOptions = projects;

        if (!projects.length) {
          this.errorMessage = 'Nenhum projeto foi encontrado. Cadastre projetos antes de criar avaliações.';
          this.isSubmitButtonDisabled = true;
        }
      },
      error: () => {
        this.errorMessage = 'Erro ao carregar projetos. Tente novamente mais tarde.';
        this.isSubmitButtonDisabled = true;
      }
    });
  }

  getSelectedProjectObject(): Project | undefined {
    return this.inputProjectsOptions.find(project => project.id == Number(this.inputProjectSelectedId));
  }
}
