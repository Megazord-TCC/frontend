import { Component } from '@angular/core';

@Component({
  selector: 'app-portfolio-modal',
  imports: [],
  templateUrl: './portfolio-modal.component.html',
  styleUrl: './portfolio-modal.component.scss'
})
export class PortfolioModalComponent {

}
