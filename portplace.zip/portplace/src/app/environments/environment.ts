export const environment = {
  production: false,
  //apiUrl: 'https://portplace-backend.greenstone-ec062121.brazilsouth.azurecontainerapps.io/api/v1'
  apiUrl: 'http://localhost:8080/api/v1',
};
