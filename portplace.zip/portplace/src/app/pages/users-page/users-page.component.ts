import { Component } from '@angular/core';

@Component({
  selector: 'app-users-page',
  imports: [],
  templateUrl: './users-page.component.html',
  styleUrl: './users-page.component.scss'
})
export class UsersPageComponent {

}
