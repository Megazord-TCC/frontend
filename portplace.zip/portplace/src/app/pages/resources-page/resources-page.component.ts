import { Component } from '@angular/core';

@Component({
  selector: 'app-resources-page',
  imports: [],
  templateUrl: './resources-page.component.html',
  styleUrl: './resources-page.component.scss'
})
export class ResourcesPageComponent {

}
